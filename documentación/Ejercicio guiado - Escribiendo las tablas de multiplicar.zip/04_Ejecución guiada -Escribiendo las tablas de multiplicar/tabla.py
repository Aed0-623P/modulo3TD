for numero1 in range(10):
    print(f"La tabla del {numero1} es:____ \n")

    for numero2 in range(10):
        print(f"{numero1} * {numero2} = {numero1 * numero2}")

